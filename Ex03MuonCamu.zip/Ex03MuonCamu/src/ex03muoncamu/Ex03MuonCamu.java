/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex03muoncamu;

/**
 *
 * @author windows10 user
 */
public class Ex03MuonCamu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ValoAgent neon= new ValoAgent ("Neon", "Duelist", 19);
        ValoAgent omen = new ValoAgent ("Omen", "Controller", 03);
        ValoAgent kj = new ValoAgent ("Killjoy", "Sentinel", 04);
        
        System.out.println("Agent Name: " + neon.agentName + "\n" + "Agent Role: " + neon.agentRole + "\n" + "Agent No. : " + neon.agentNumber + "\n");
        System.out.println("Agent Name: " + omen.agentName + "\n" + "Agent Role: " + omen.agentRole + "\n" + "Agent No. : " + omen.agentNumber + "\n");
        System.out.println("Agent Name: " + kj.agentName + "\n" + "Agent Role: " + kj.agentRole + "\n" + "Agent No. : " + kj.agentNumber + "\n");
        
        
        Song leaves = new Song("Leaves", "OPM", 0, true);
        Song otg = new Song("On the Ground", "K-pop", 95, true);
        
        Singer swh = new Singer("Sunwoo Han", 0, 0.0, leaves);
        
        swh.performForAudience(12);
        swh.changeFavSong(otg);
    }
    
}
