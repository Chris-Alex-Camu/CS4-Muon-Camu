/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex04muoncamu;
import java.util.Scanner;
/**
 *
 * @author windows10 user
 */
public class Ex04MuonCamu {
    
    public static void main(String[] args) {
        ValoAgent neon= new ValoAgent ("Neon", "Duelist", 19);
        ValoAgent omen = new ValoAgent ("Omen", "Controller", 03);
        ValoAgent kj = new ValoAgent ("Killjoy", "Sentinel", 04);
        
        System.out.println("Agent Name: " + neon.getAgentName() + "\n" + "Agent Role: " + neon.getAgentRole() + "\n" + "Agent No. : " + neon.getAgentNumber() + "\n");
        System.out.println("Agent Name: " + omen.getAgentName() + "\n" + "Agent Role: " + omen.getAgentRole() + "\n" + "Agent No. : " + omen.getAgentNumber() + "\n");
        System.out.println("Agent Name: " + kj.getAgentName() + "\n" + "Agent Role: " + kj.getAgentRole() + "\n" + "Agent No. : " + kj.getAgentNumber() + "\n");
        
        
        Song leaves = new Song("Leaves", "OPM", true);
        Song otg = new Song("On the Ground", "K-pop", true);
        
        Singer ben = new Singer("Ben");
        Singer swh = new Singer("Sunwoo Han", leaves);
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Audience Count: ");
        int audience = sc.nextInt();
        sc.nextLine();
        
        swh.performForAudience(audience);
        swh.changeFavSong(otg);
        ben.changeFavSong(leaves);
        swh.performForAudience(audience, ben);
        
    }
    
}

