package ex04muoncamu;


public class Singer {
    private String singerName;
    private int noOfPerformances;
    private double earnings;
    private Song favoriteSong;
    private static int totalPerf = 0;
    public Singer (String sn){
        this.singerName = sn;
        this.noOfPerformances = 0;
        this.earnings = 0.0;
        this.favoriteSong = null;
    }
    
    public Singer (String sn, Song favSong){
        this.singerName = sn;
        this.noOfPerformances = 0;
        this.earnings = 0.0;
        this.favoriteSong = favSong;
    }
    public int getNoOfPerformances(){
        return noOfPerformances;
    }
    public void performForAudience(int people){
        noOfPerformances ++;
        earnings += 100 * people;
        System.out.println("\n The singer named " + singerName + " performed for " + people + " people, and earned " + earnings + " pesos.");
    }
    public void performForAudience(int people, Singer partner){
        double totalEarnings = 100 * people;
        this.earnings += totalEarnings/2;
        partner.earnings += totalEarnings/2;
        totalPerf++;
        this.noOfPerformances++;
        partner.noOfPerformances++;
        System.out.println("\n" + this.singerName + " & " + partner.singerName + " performed for " + people + " people, and earned " + totalEarnings/2 + " pesos each.");
    }
    public void changeFavSong (Song favSong){
        favoriteSong = favSong;
        System.out.println("\n The singer named " + singerName + " changed their favorite song to " + favoriteSong.getSongName() + "!");
    }
    
    
    
    
}
