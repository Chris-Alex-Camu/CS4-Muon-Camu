/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex04muoncamu;

/**
 *
 * @author windows10 user
 */
public class Song {
    private String title;
    private String genre;
    private int songPopularity, timesPlayed;
    private boolean albumSong;

    public Song (String t){
        this.title = t;
        this.songPopularity = 0;
        this.timesPlayed = 0;
    }
    
    public Song (String t, String g, boolean as){
        this.title = t;
        this.genre = g;
        this.songPopularity = 0;
        this.albumSong = as;
        this.timesPlayed = 0;
    }
    public String getSongName(){
        return title;
    }
    public String getGenre(){
        return genre;
    }
    public int getSongPopularity(){
        return songPopularity;
    }
    public int getPlayed(){
        return timesPlayed;
    }
    public boolean getAlbumSong(){
        return albumSong;
    }
    public void play(){
        timesPlayed++;
    }
    public void favorite(){
        songPopularity++;
    }
    
            
}
