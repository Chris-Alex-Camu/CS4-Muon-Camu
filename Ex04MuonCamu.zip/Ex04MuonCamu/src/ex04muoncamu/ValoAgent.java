/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex04muoncamu;

/**
 *
 * @author windows10 user
 */
public class ValoAgent {
    private String agentName;
    private String agentRole;
    private int agentNumber;
    
    public ValoAgent (String agna, String agro, int agno){
        agentName = agna;
        agentRole = agro;
        agentNumber = agno;
    }
    public String getAgentName(){
        return agentName;
    }
    public String getAgentRole(){
        return agentRole;
    }
    public int getAgentNumber(){
        return agentNumber;
    }
}
