/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex05muoncamu;
import java.util.*;

public class Store {
    private String name;
    private double earnings;
    private ArrayList<Item> itemList;
    private static ArrayList<Store> storeList = new ArrayList();

    public Store(String name){
        this.name = name;
        this.earnings = 0.0;
        this.itemList = new ArrayList();
        storeList.add(this);
      // Initialize name to parameter and earnings to zero
      // Initialize itemList as a new ArrayList
      // add 'this' store to storeList
    }

    public String getName(){
      return name;
    }
    public double getEarnings(){
      return earnings;
    }
    public void sellItem(int index){
        if (index < itemList.size() && index >= 0){
            Item itemFound = itemList.get(index);
            earnings += itemFound.getCost();
            System.out.println(itemFound.getName() + " was sold for " + itemFound.getCost());
        }
        else {
            System.out.println(this.name + " does not sell that many items. \n");
        }
      // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
      // get Item at index from itemList and add its cost to earnings
      // print statement indicating the sale
    }
    public void sellItem(String name){
        boolean found = false;
        for(Item i : itemList){
            if (i.getName().equals(name)){
                earnings += i.getCost();
                System.out.println(i.getName() + " was sold for " + i.getCost());
                found = true;
            }
        }
        if (!found){
            System.out.println(this.name + " does not sell " + name +". \n");
        }
      // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
      // get Item from itemList and add its cost to earnings
      // print statement indicating the sale
    }
    public void sellItem(Item i){
      // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
      // get Item i from itemList and add its cost to earnings
      // print statement indicating the sale
      if(itemList.contains(i)){
            earnings += i.getCost();
            System.out.println(i.getName() + " was sold for " + i.getCost());
      }
      else {
          System.out.println(this.name + " does not sell " + i.getName() +". \n");
      }
    }
    public void addItem(Item i){
        itemList.add(i);
      // add Item i to store's itemList
    }
    public void filterType(String type){
        for(Item i : itemList){
      // loop over itemList and print all items with the specified type
            if(i.getType().equals(type)){
                System.out.println(i.getName());
            }
        }
    }
    public void filterCheap(double maxCost){
      // loop over itemList and print all items with a cost lower than or equal to the specified value
      for(Item i : itemList){
          if (i.getCost() <= maxCost){
              System.out.println(i.getName());
          }
      }
    }
    public void filterExpensive(double minCost){
      // loop over itemList and print all items with a cost higher than or equal to the specified value
      for(Item i : itemList){
          if (i.getCost() >= minCost){
              System.out.println(i.getName());
          }
      }
    }
    public static void printStats(){
      // loop over storeList and print the name and the earnings'Store.java'
      for (Store n : storeList){
          System.out.println("Store : " + n.name + "\nEarnings: " + n.earnings);
      }
      
    }
}
