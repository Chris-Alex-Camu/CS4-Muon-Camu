/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package fxexer14;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

/**
 *
 * @author windows10 user
 */
public class FXMLDocumentController implements Initializable {
    @FXML private Text subj, grades, units;
    @FXML private Button back, next, search;
    @FXML private TextField searchbar;
    @FXML private ImageView pic;
    private Subject displayed;
    
    @FXML private void next(ActionEvent event){
        int i = Subject.getSubjectIndex(displayed);
        i++;
        Subject nextSubject = Subject.getSubjectbyIndex(i);
        displaySubject(nextSubject);
        
    }
    
    public void enableButton(){
        int i = Subject.getSubjectIndex(displayed);
        if (i==0){
            back.setDisable(true);
        }
        else {
            back.setDisable(false);
        }
    }
    
    @FXML private void back(ActionEvent event){
        int i = Subject.getSubjectIndex(displayed);
        i--;
        Subject prevSubject = Subject.getSubjectByIndex(i);
        displaySubject(prevSubject);
    }
    
    @FXML private void search(ActionEvent event){
        
    }
    
    public void displaySubject(Subject a){
        subj.setText(a.getName());
        units.setText(Double.toString(a.getUnits()));
        grades.setText(Double.toString(a.getGrade()));
        Image img = new Image(getClass().getResourceAsStream(a.getImgFileName()));
        pic.setImage(img);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    
    
}
