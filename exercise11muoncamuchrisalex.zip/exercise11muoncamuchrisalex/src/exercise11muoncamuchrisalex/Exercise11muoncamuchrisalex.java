/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package exercise11muoncamuchrisalex;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.*;


/**
 *
 * @author windows10 user
 */
public class Exercise11muoncamuchrisalex extends Application {
    
    Subject math = new Subject("Math", "math.png", 4, 1.75);
    Subject bio = new Subject("Biology", "biology.png", 3, 2.0);
    Subject chem = new Subject("Chemistry", "chemistry.png", 3, 1.5);
    Subject physics = new Subject("Physics", "physics.png", 3, 1.75);
    Subject cs = new Subject("CS", "computer science.png", 1, 1.5);
    Subject displayedSubject = math;
    
    @Override
    public void start(Stage primaryStage) {
        Text data = new Text();
        data.setFont(new Font("Times New Roman",20));
        data.setFill(Color.BLUE);
        data.setText("Subject: " + displayedSubject.getName() + "\n" +   
                     "Units: " + displayedSubject.getUnits() + "\n" +
                     "Grade: " + displayedSubject.getGrade());
        
        ImageView logo = new ImageView();
        Image img = new Image("image/" + "math.png");
        logo.setImage(img);
        
        
        /*Button btn = new Button();
        btn.setText("Next");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
        */
        StackPane root = new StackPane();
        // root.getChildren().add(btn);
        root.getChildren().add(data);
        root.getChildren().add(logo);
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
